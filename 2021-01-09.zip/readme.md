## Socreboard

`php artisan migrate:fresh --seed`
`php artisan serve --host=192.168.1.101 --port=8080`