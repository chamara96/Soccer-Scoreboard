<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <h4>Instruction</h4>
        </div>
        <p>1. This is Main Admin Dashboard<br>
        2. Super Admin can create user and assign roles and permissions to each game. (Assigning part is not completed yet, but in next stage) <br>
        3. <strong>Scoreboard Manage</strong> <br>
        &emsp; &emsp;  a) First create <b>Teams</b><br>
        &emsp; &emsp;  b) Then create <b>Timers</b><br>
        &emsp; &emsp;  c) Then create a <b>Game</b><br>
        &emsp; &emsp;  d) Then click <b>view</b> button in the Game list. <br>
        &emsp; &emsp;  e) click <b>Go to Contol Panel</b> button in the Game details view. <br>
        &emsp; &emsp;  f) Select a timer and click Start then Score Controlling button can increase or decrease score. Click on the Public view button to show Public Audience's view.


    </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FIVERR-WORKS\ScoreBoard\resources\views/home.blade.php ENDPATH**/ ?>