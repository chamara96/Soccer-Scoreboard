<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Create Team
    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.teams.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('team_name') ? 'has-error' : ''); ?>">
                <label for="team_name">Team Name*</label>
                <input type="text" id="team_name" name="team_name" class="form-control"
                    value="<?php echo e(old('team_name', isset($teams) ? $teams->team_name : '')); ?>" required>
                <?php if($errors->has('team_name')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('team_name')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('team_logo') ? 'has-error' : ''); ?>">
                <label for="team_logo">Team Logo*</label>
                <input type="file" id="team_logo" name="team_logo" class="form-control"
                    value="<?php echo e(old('team_logo', isset($teams) ? $teams->team_logo : '')); ?>" required>
                <?php if($errors->has('team_logo')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('team_logo')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FIVERR-WORKS\ScoreBoard\resources\views/admin/scoreboard/teams/create.blade.php ENDPATH**/ ?>