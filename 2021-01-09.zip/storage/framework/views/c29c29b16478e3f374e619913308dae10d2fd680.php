<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Add Song
    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.songs.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('song_name') ? 'has-error' : ''); ?>">
                <label for="song_name">Song Title*</label>
                <input type="text" id="song_name" name="song_name" class="form-control"
                    value="<?php echo e(old('song_name', isset($songs) ? $songs->song_name : '')); ?>" required>
                <?php if($errors->has('song_name')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('song_name')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('songclip_raw') ? 'has-error' : ''); ?>">
                <label for="songclip_raw">Song Clip*</label>
                <input type="file" id="songclip_raw" name="songclip_raw" class="form-control"
                    value="<?php echo e(old('songclip_raw', isset($songs) ? $songs->songclip_raw : '')); ?>" required>
                <?php if($errors->has('songclip_raw')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('songclip_raw')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FIVERR-WORKS\ScoreBoard\resources\views/admin/scoreboard/songs/create.blade.php ENDPATH**/ ?>