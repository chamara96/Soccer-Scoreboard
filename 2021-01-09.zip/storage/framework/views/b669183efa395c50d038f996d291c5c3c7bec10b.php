<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Scoreboard Settings
    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.settings.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div>
                <label for=""><?php echo e($settings->name); ?></label>
                <img height="200px" src="/storage/images/backgrounds/<?php echo e($settings->value); ?>" alt="">
            </div>

            <div class="form-group <?php echo e($errors->has('bg_path') ? 'has-error' : ''); ?>">
                <label for="bg_path">Background*</label>
                <input type="file" id="bg_path" name="bg_path" class="form-control"
                    value="" required>
                <?php if($errors->has('bg_path')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('bg_path')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>

            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FIVERR-WORKS\ScoreBoard\resources\views/admin/scoreboard/settings/create.blade.php ENDPATH**/ ?>