<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Create advertisement
    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.ads.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('ad_title') ? 'has-error' : ''); ?>">
                <label for="ad_title">Ad Title*</label>
                <input type="text" id="ad_title" name="ad_title" class="form-control"
                    value="<?php echo e(old('ad_title', isset($ads) ? $ads->ad_title : '')); ?>" required>
                <?php if($errors->has('ad_title')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('ad_title')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('ad_path') ? 'has-error' : ''); ?>">
                <label for="ad_path">Ad path*</label>
                <input type="file" id="ad_path" name="ad_path" class="form-control"
                    value="<?php echo e(old('ad_path', isset($ads) ? $ads->path : '')); ?>" required>
                <?php if($errors->has('ad_path')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('ad_path')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>

            <div class="form-group row">
                <label for="dropdown" class="col-sm-4 col-form-label text-md-right">Select Game</label>

                <div class="col-md-5">
                    <select class="form-control<?php echo e($errors->has('game_id') ? ' has-error' : ''); ?>" name="game_id">
                        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($game->id); ?>"><?php echo e($game->game_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php if($errors->has('game_id')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('game_id')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FIVERR-WORKS\ScoreBoard\resources\views/admin/scoreboard/ads/create.blade.php ENDPATH**/ ?>