<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Edit Game
    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.games.update", [$game->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group <?php echo e($errors->has('game_name') ? 'has-error' : ''); ?>">
                <label for="game_name">Game Name*</label>
                <input type="text" id="game_name" name="game_name" class="form-control"
                    value="<?php echo e(old('game_name', isset($game) ? $game->game_name : '')); ?>" required>
                <?php if($errors->has('game_name')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('game_name')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('date') ? 'has-error' : ''); ?>">
                <label for="date">Game Date*</label>
                <input type="text" id="date" name="date" class="form-control"
                    value="<?php echo e(old('date', isset($game) ? $game->date : '')); ?>" required>
                <?php if($errors->has('date')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('date')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('ground') ? 'has-error' : ''); ?>">
                <label for="ground">Ground*</label>
                <input type="text" id="ground" name="ground" class="form-control"
                    value="<?php echo e(old('ground', isset($game) ? $game->ground : '')); ?>" required>
                <?php if($errors->has('ground')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('ground')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('game_logo_raw') ? 'has-error' : ''); ?>">
                <label for="game_logo_raw">Game Logo*</label>
                <input type="file" id="game_logo_raw" name="game_logo_raw" class="form-control">
                <?php if($errors->has('game_logo_raw')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('game_logo_raw')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
                <div>
                    <img height="150px" src="/storage/images/game_logo/<?php echo e($game->game_logo); ?>" alt="">
                </div>
            </div>

            <div class="form-group row">
                <label for="dropdown" class="col-sm-4 col-form-label text-md-right">Team A</label>

                <div class="col-md-5">
                    <select class="form-control<?php echo e($errors->has('team_a') ? ' has-error' : ''); ?>" name="team_a">
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($team->id==$game->team_a ? 'selected' : ''); ?> value="<?php echo e($team->id); ?>">
                            <?php echo e($team->team_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php if($errors->has('team_a')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('team_a')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group row">
                <label for="dropdown" class="col-sm-4 col-form-label text-md-right">Team B</label>

                <div class="col-md-5">
                    <select class="form-control<?php echo e($errors->has('team_b') ? ' has-error' : ''); ?>" name="team_b">
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($team->id==$game->team_b ? 'selected' : ''); ?> value="<?php echo e($team->id); ?>">
                            <?php echo e($team->team_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php if($errors->has('team_b')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('team_b')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>

            
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FIVERR-WORKS\ScoreBoard\resources\views/admin/scoreboard/games/edit.blade.php ENDPATH**/ ?>