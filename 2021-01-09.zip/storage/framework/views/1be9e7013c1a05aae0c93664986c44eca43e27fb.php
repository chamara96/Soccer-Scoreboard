<?php $__env->startSection('content'); ?>

<div style="margin-bottom: 10px;" class="row">
    <div class="col-lg-12">
        <a class="btn btn-success" href="<?php echo e(route("admin.whistles.create")); ?>">
            Add Whistles
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        Whistles List
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Permission">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            Id
                        </th>
                        <th>
                            Whistle Name
                        </th>
                        <th>
                            Sound Clip
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $whistles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $whistle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-entry-id="<?php echo e($whistle->id); ?>">
                        <td>

                        </td>
                        <td>
                            <?php echo e($whistle->id ?? ''); ?>

                        </td>
                        <td>
                            <?php echo e($whistle->whistle_name ?? ''); ?>

                        </td>
                        <td>
                            <audio controls>
                                <source src="/storage/sounds/whistle_clips/<?php echo e($whistle->soundclip); ?>" type="audio/mpeg"> 
                            </audio>
                            
                            
                        </td>
                        <td>
                            <a class="btn btn-xs btn-primary"
                                href="<?php echo e(route('admin.whistles.show', $whistle->id)); ?>">
                                <?php echo e(trans('global.view')); ?>

                            </a>

                            <a class="btn btn-xs btn-info"
                                href="<?php echo e(route('admin.whistles.edit', $whistle->id)); ?>">
                                <?php echo e(trans('global.edit')); ?>

                            </a>

                            <form action="<?php echo e(route('admin.whistles.destroy', $whistle->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');"
                                style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                            </form>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>


    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##

<script>
    $(function () {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
        let deleteButtonTrans = "<?php echo e(trans('global.datatables.delete')); ?>"
        let deleteButton = {
            text: deleteButtonTrans,
            url: "<?php echo e(route('admin.permissions.mass_destroy')); ?>",
            className: 'btn-danger',
            action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
                    return $(entry).data('entry-id')
                });

                if (ids.length === 0) {
                    alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

                    return
                }

                if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                    $.ajax({
                        headers: { 'x-csrf-token': _token },
                        method: 'POST',
                        url: config.url,
                        data: { ids: ids, _method: 'DELETE' }
                    })
                        .done(function () { location.reload() })
                }
            }
        }
        dtButtons.push(deleteButton)

        $.extend(true, $.fn.dataTable.defaults, {
            order: [[1, 'desc']],
            pageLength: 100,
        });
        $('.datatable-Permission:not(.ajaxTable)').DataTable({ buttons: dtButtons })
        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FIVERR-WORKS\ScoreBoard\resources\views/admin/scoreboard/whistles/index.blade.php ENDPATH**/ ?>