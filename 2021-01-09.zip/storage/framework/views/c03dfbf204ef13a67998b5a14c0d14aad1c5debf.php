<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Edit Teams
    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.teams.update", [$team->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('team_name') ? 'has-error' : ''); ?>">
                <label for="team_name">Team Name*</label>
                <input type="text" id="team_name" name="team_name" class="form-control"
                    value="<?php echo e(old('team_name', isset($team) ? $team->team_name : '')); ?>" required>
                <?php if($errors->has('team_name')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('team_name')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    
                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('team_logo') ? 'has-error' : ''); ?>">
                <label for="team_logo">Team Logo*</label>
                
                <input type="file" id="team_logo" name="team_logo" class="form-control" value="/storage/images/team_logo/<?php echo e($team->logo); ?>">
                <?php if($errors->has('team_logo')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('team_logo')); ?>

                </em>
                <?php endif; ?>
                <div>
                    <img height="150px" src="/storage/images/team_logo/<?php echo e($team->logo); ?>" alt="">
                </div>
                <p class="helper-block">
                    
                </p>
            </div>

            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>

            
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FIVERR-WORKS\ScoreBoard\resources\views/admin/scoreboard/teams/edit.blade.php ENDPATH**/ ?>