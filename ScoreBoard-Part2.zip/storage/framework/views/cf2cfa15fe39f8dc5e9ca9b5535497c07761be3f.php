<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Show Game
    </div>

    <div class="card-body">
        <div class="mb-2">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            Id
                        </th>
                        <td>
                            <?php echo e($game->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Game Name
                        </th>
                        <td>
                            <?php echo e($game->game_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Game Date
                        </th>
                        <td>
                            <?php echo e($game->date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Ground
                        </th>
                        <td>
                            <?php echo e($game->ground); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Game Logo
                        </th>
                        <td>
                            <img src="/storage/images/game_logo/<?php echo e($game->game_logo); ?>" height="150px" alt="">
                        </td>
                    </tr>
                    <tr>
                        <th>
                            Team A
                        </th>
                        <td>
                            <?php echo e($teams->where('id', $game->team_a)->first()->team_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Team B
                        </th>
                        <td>
                            <?php echo e($teams->where('id', $game->team_b)->first()->team_name); ?>

                        </td>
                    </tr>


                </tbody>
            </table>
            <a style="margin-top:20px;" class="btn btn-default" href="<?php echo e(url()->previous()); ?>">
                <?php echo e(trans('global.back_to_list')); ?>

            </a>

            <?php if($game->status != 2): ?>
            <a style="margin-top:20px;" class="btn btn-success" target="_blank"
                href="<?php echo e(route("admin.score.index", ['ref' => Crypt::encrypt($game->id) ])); ?>">
                Go to Control Panel
            </a>
            <a style="margin-top:20px;" class="btn btn-danger"
                href="<?php echo e(route("admin.gameend", ['ref' => Crypt::encrypt($game->id) ])); ?>">
                End Game
            </a>
            <?php else: ?>
            <a href="#">
                Game has ended. Create new one
            </a>
            <?php endif; ?>

            <?php if($game->status !=0): ?>
            <a style="margin-top:20px;" class="btn btn-success" target="_blank"
                href="<?php echo e(route("publicscore", ['ref' => $game->id ])); ?>">
                Go to Public View
            </a>
            <?php endif; ?>

        </div>

        <nav class="mb-3">
            <div class="nav nav-tabs">

            </div>
        </nav>
        <div class="tab-content">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FIVERR-WORKS\ScoreBoard\resources\views/admin/scoreboard/games/show.blade.php ENDPATH**/ ?>