<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>ABCD</title>
    <meta name="generator" content="Google Web Designer 10.0.1.1204">
    <style type="text/css" id="gwd-text-style">
        p {
            margin: 0px;
        }

        h1 {
            margin: 0px;
        }

        h2 {
            margin: 0px;
        }

        h3 {
            margin: 0px;
        }
    </style>
    <style type="text/css">
        html,
        body {
            width: 100%;
            height: 100%;
            margin: 0px;
        }

        body {
            background-color: transparent;
            transform: perspective(1400px) matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
            transform-style: preserve-3d;
        }

        .gwd-div-15zr {
            position: absolute;
            top: 0px;
            left: 0px;
            width: 578px;
            height: 73px;
            transform-origin: 50% 50% 0px;
        }

        .gwd-h3-tpc8 {
            position: absolute;
            transform-origin: 50% 50% 0px;
            margin: 0px;
            padding: 0px;
            width: 532px;
            text-align: center;
            font-size: 25px;
            height: 41px;
            left: 23px;
            top: 16px;
            font-family: Verdana;
        }

        .gwd-img-v1rk {
            position: absolute;
            width: 150px;
            height: 150px;
            left: 81px;
            top: 73px;
        }

        .gwd-h1-1heh {
            position: absolute;
            width: 66px;
            font-size: 50px;
            font-family: Verdana;
            text-align: center;
            height: 61px;
            transform-origin: 50% 50% 0px;
            left: 123px;
            top: 223px;
        }

        .gwd-div-1djt {
            position: absolute;
            top: 244px;
            width: 66px;
            height: 61px;
            left: 48px;
        }

        .gwd-div-4mdm {
            left: 198px;
        }

        .gwd-div-3goh {
            position: absolute;
            left: 23px;
            width: 532px;
            transform-origin: 50% 50% 0px;
            top: 382px;
            height: 200px;
        }

        .gwd-h2-w3h3 {
            position: absolute;
            transform-origin: 50% 50% 0px;
            text-align: center;
            font-family: Verdana;
            font-size: 0px;
            top: 382px;
            height: 58px;
            left: 123px;
            width: 326px;
        }

        .gwd-span-84si {
            font-family: Verdana;
            font-size: 0px;
        }

        .gwd-span-yp9r {
            font-size: 35px;
        }

        .gwd-span-1plb {
            font-size: 35px;
        }

        .gwd-div-ir30 {
            position: absolute;
            left: 135px;
            top: 413px;
            width: 96px;
            height: 61px;
        }

        .gwd-div-hf9t {
            top: 452px;
            left: 401px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-img-14yw {
            top: 122px;
        }

        .gwd-div-jb3h {
            height: 61px;
            transform-origin: 50% 50%;
            top: 452px;
            left: 75px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-div-myza {
            top: 284px;
        }

        .gwd-div-e43i {
            height: 58px;
            transform-origin: 50% 50% 0px;
            top: 286px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-h1-d9nl {
            height: 61px;
            top: 272px;
        }

        .gwd-h3-1kw0 {
            position: absolute;
            height: 22px;
            transform-origin: 50% 50% 0px;
            width: 216px;
            text-align: center;
            font-family: Verdana;
            top: 86px;
            left: 48px;
        }

        [data-gwd-group="Group1"] {
            width: 266px;
            height: 309px;
        }

        .gwd-div-1s5t {
            position: absolute;
            top: 85px;
            height: 269px;
            left: 289px;
            width: 266px;
            transform-origin: 50% 50% 0px;
        }

        .gwd-div-1sit {
            left: 23px;
            top: 76px;
            height: 287px;
            border-style: solid;
            border-width: 2px;
        }

        .gwd-div-k2b7 {
            top: 76px;
            height: 287px;
            border-style: solid;
            border-width: 2px;
        }

        .gwd-h3-1vgu {
            left: 314px;
        }

        .gwd-img-18sh {
            left: 341px;
            top: 120px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-h1-1u27 {
            left: 383px;
        }

        .gwd-div-1rf8 {
            left: 308px;
            top: 283px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-div-qmlw {
            left: 458px;
            top: 285px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-div-u1fm {
            position: absolute;
            left: 189px;
            top: 452px;
            width: 194px;
            height: 22px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-div-ilh3 {
            position: absolute;
            left: 189px;
            top: 482.5px;
            width: 194px;
            height: 86.5px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-div-wyu1 {
            top: 285px;
            border-style: solid;
            border-width: 1px;
        }

        .gwd-img-2zan {
            border-style: solid;
            border-width: 1px;
        }
    </style>
</head>

<body class="htmlNoPages">
    <div class="gwd-div-1s5t gwd-div-k2b7"></div>
    <div class="gwd-div-1s5t gwd-div-1sit"></div>
    <div class="gwd-div-15zr"></div>
    <h3 class="gwd-h3-tpc8">Game Title</h3>
    <img class="gwd-img-v1rk gwd-img-14yw gwd-img-2zan">
    <img class="gwd-img-v1rk gwd-img-14yw gwd-img-18sh">
    <h1 class="gwd-h1-1heh gwd-h1-d9nl">3</h1>
    <h1 class="gwd-h1-1heh gwd-h1-d9nl gwd-h1-1u27">3</h1>
    <div class="gwd-div-1djt gwd-div-myza gwd-div-wyu1"></div>
    <div class="gwd-div-1djt gwd-div-myza gwd-div-qmlw"></div>
    <div class="gwd-div-1djt gwd-div-myza gwd-div-1rf8"></div>
    <div class="gwd-div-1djt gwd-div-4mdm gwd-div-e43i"></div>
    <div class="gwd-div-3goh"></div>
    <h2 class="gwd-h2-w3h3"><span class="gwd-span-1plb">00:00</span><br></h2>
    <div class="gwd-div-ir30 gwd-div-jb3h"></div>
    <div class="gwd-div-ir30 gwd-div-hf9t"></div>
    <h3 class="gwd-h3-1kw0">Team A</h3>
    <h3 class="gwd-h3-1kw0 gwd-h3-1vgu">Team A</h3>
    <div class="gwd-div-u1fm"></div>
    <div class="gwd-div-ilh3"></div>
</body>

</html>